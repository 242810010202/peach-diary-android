# 桃子日记 Android 项目（独立副本）

此项目从原有 peach-app 网页复制而来，**不会修改 GitHub 仓库**。

## 已准备
- 网页副本：`www/index.html`
- App 名称：桃子日记
- Android 包名：`com.peachdiary.app`
- 图标素材：`assets/`

## 下一步（Windows）
1. 安装 Node.js LTS（建议 Node.js 22 或更新的受支持 LTS）。
2. 安装 Android Studio，并在首次启动时安装 Android SDK。
3. 在此文件夹地址栏输入 `cmd` 后回车，打开命令提示符。
4. 运行 `npm install`
5. 运行 `npx cap add android`
6. 运行 `npx cap sync android`
7. 运行 `npx cap open android`，在 Android Studio 中构建 APK。

注意：这个压缩包是项目准备包，还不是可直接安装的 APK。首次构建仍需要安装工具并联网下载依赖。
日记使用 localStorage，首次生成 APK 后必须实际测试保存、编辑和删除功能。现有网页的日记数据不会自动同步到其他设备。


## GitHub Actions 自动构建
将此项目文件放入独立仓库根目录，并添加 `.github/workflows/main.yml` 工作流后，GitHub Actions 可尝试构建 debug APK。生成的 APK 会作为 Actions artifact 提供下载。
