import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.peachdiary.app',
  appName: '桃子日记',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
